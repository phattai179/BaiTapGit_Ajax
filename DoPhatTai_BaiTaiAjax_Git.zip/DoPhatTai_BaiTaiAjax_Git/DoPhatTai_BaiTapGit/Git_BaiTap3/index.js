console.log('master');

console.log('Làm bài tập');

var BaiTapBuoi1 = function(){
    console.log('doneBaiTapBuoi1');
}

var BaiTapBuoi2 = function(){
    console.log('doneBaiTapBuoi2');
}

var BaiTapBuoi3 = function(){
    console.log('doneBaiTapBuoi3');
}

var buoi3 = BaiTapBuoi3();